"use client"

import type React from "react"

import { useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { properties } from "@/data/properties"
import { ArrowLeft, HelpCircle, Check } from "lucide-react"
import Link from "next/link"
import Tooltip from "@/components/tooltip"

export default function SendOfferPage() {
  const params = useParams()
  const router = useRouter()
  const propertyId = params.id as string

  const property = properties.find((p) => p.id === propertyId)

  const [offerPrice, setOfferPrice] = useState(property ? property.price : 0)
  const [downPayment, setDownPayment] = useState(offerPrice * 0.2)
  const [paymentMethod, setPaymentMethod] = useState<"Cash" | "Mortgage">("Mortgage")
  const [closingDate, setClosingDate] = useState("")
  const [inspectionContingency, setInspectionContingency] = useState<
    "Waived" | "Structural and Environmental" | "Complete"
  >("Complete")
  const [financingContingency, setFinancingContingency] = useState<"Waived" | "Not Waived">("Not Waived")
  const [appraisalContingency, setAppraisalContingency] = useState<"Waived" | "Not Waived">("Not Waived")
  const [appraisalGap, setAppraisalGap] = useState(10000)
  const [additionalInfo, setAdditionalInfo] = useState("")

  const [tooltips, setTooltips] = useState<Record<string, boolean>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  const toggleTooltip = (id: string) => {
    setTooltips((prev) => ({
      ...prev,
      [id]: !prev[id],
    }))
  }

  // Generate available closing dates (next 30-90 days)
  const availableClosingDates = Array.from({ length: 60 }, (_, i) => {
    const date = new Date()
    date.setDate(date.getDate() + i + 30)
    return date.toISOString().split("T")[0]
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false)
      setIsSuccess(true)

      // Redirect back to property page after 2 seconds
      setTimeout(() => {
        router.push(`/property/${propertyId}`)
      }, 2000)
    }, 1500)
  }

  if (!property) {
    return (
      <div className="container mx-auto p-6">
        <h1 className="text-2xl font-bold text-neutral-900 mb-4">Property Not Found</h1>
        <p className="text-neutral-600 mb-6">The property you're looking for doesn't exist or has been removed.</p>
        <Link href="/buyer" className="text-primary-600 font-medium hover:underline">
          Back to Home
        </Link>
      </div>
    )
  }

  return (
    <div className="container mx-auto p-4 md:p-6 max-w-3xl">
      <Link
        href={`/property/${propertyId}`}
        className="inline-flex items-center text-neutral-600 hover:text-neutral-900 mb-6"
      >
        <ArrowLeft size={18} className="mr-2" />
        Back to Property
      </Link>

      <div className="bg-white rounded-xl shadow-md overflow-hidden">
        <div className="p-6">
          <h1 className="text-2xl font-bold text-neutral-900 mb-2">Make an Offer</h1>
          <p className="text-neutral-600 mb-6">
            {property.address}, {property.city}, {property.state}
          </p>

          {isSuccess ? (
            <div className="bg-success/10 text-success p-4 rounded-lg flex items-start">
              <Check size={24} className="mr-3 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-lg">Offer Submitted!</h3>
                <p>
                  Your offer has been submitted to the seller. We'll notify you when they respond. You can view the
                  details of your offer on the property page.
                </p>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <div className="flex items-center mb-2">
                    <label className="block text-neutral-700 font-medium">Offer Price</label>
                    <button
                      type="button"
                      className="ml-2 text-neutral-500"
                      onClick={() => toggleTooltip("offerPrice")}
                      aria-label="Show information about offer price"
                    >
                      <HelpCircle size={16} />
                    </button>
                    {tooltips.offerPrice && (
                      <Tooltip
                        content="The amount you're offering to pay for the property. The listing price is $${property.price.toLocaleString()}."
                        onClose={() => toggleTooltip("offerPrice")}
                      />
                    )}
                  </div>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-500">$</span>
                    <input
                      type="number"
                      value={offerPrice}
                      onChange={(e) => {
                        const value = Number.parseInt(e.target.value)
                        setOfferPrice(value)
                        setDownPayment(value * 0.2)
                      }}
                      className="w-full pl-8 pr-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500"
                      required
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center mb-2">
                    <label className="block text-neutral-700 font-medium">Down Payment</label>
                    <button
                      type="button"
                      className="ml-2 text-neutral-500"
                      onClick={() => toggleTooltip("downPayment")}
                      aria-label="Show information about down payment"
                    >
                      <HelpCircle size={16} />
                    </button>
                    {tooltips.downPayment && (
                      <Tooltip
                        content="The initial payment you'll make upfront. Typically 20% of the purchase price for conventional loans."
                        onClose={() => toggleTooltip("downPayment")}
                      />
                    )}
                  </div>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-500">$</span>
                    <input
                      type="number"
                      value={downPayment}
                      onChange={(e) => setDownPayment(Number.parseInt(e.target.value))}
                      className="w-full pl-8 pr-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500"
                      required
                    />
                  </div>
                </div>
              </div>

              <div className="mb-6">
                <div className="flex items-center mb-2">
                  <label className="block text-neutral-700 font-medium">Payment Method</label>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    className={`p-3 rounded-lg border text-center ${
                      paymentMethod === "Cash"
                        ? "bg-primary-100 border-primary-500 text-primary-700"
                        : "border-neutral-200 hover:border-primary-300"
                    }`}
                    onClick={() => setPaymentMethod("Cash")}
                  >
                    Cash
                  </button>
                  <button
                    type="button"
                    className={`p-3 rounded-lg border text-center ${
                      paymentMethod === "Mortgage"
                        ? "bg-primary-100 border-primary-500 text-primary-700"
                        : "border-neutral-200 hover:border-primary-300"
                    }`}
                    onClick={() => setPaymentMethod("Mortgage")}
                  >
                    Mortgage
                  </button>
                </div>
              </div>

              <div className="mb-6">
                <div className="flex items-center mb-2">
                  <label className="block text-neutral-700 font-medium">Desired Closing Date</label>
                  <button
                    type="button"
                    className="ml-2 text-neutral-500"
                    onClick={() => toggleTooltip("closingDate")}
                    aria-label="Show information about closing date"
                  >
                    <HelpCircle size={16} />
                  </button>
                  {tooltips.closingDate && (
                    <Tooltip
                      content="The date when you want to finalize the purchase. Typically 30-60 days from offer acceptance."
                      onClose={() => toggleTooltip("closingDate")}
                    />
                  )}
                </div>
                <select
                  value={closingDate}
                  onChange={(e) => setClosingDate(e.target.value)}
                  className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500"
                  required
                >
                  <option value="">Select a closing date</option>
                  {availableClosingDates.map((date) => {
                    const formattedDate = new Date(date).toLocaleDateString("en-US", {
                      weekday: "short",
                      month: "short",
                      day: "numeric",
                      year: "numeric",
                    })

                    return (
                      <option key={date} value={date}>
                        {formattedDate}
                      </option>
                    )
                  })}
                </select>
              </div>

              <div className="mb-6">
                <div className="flex items-center mb-2">
                  <label className="block text-neutral-700 font-medium">Inspection Contingency</label>
                  <button
                    type="button"
                    className="ml-2 text-neutral-500"
                    onClick={() => toggleTooltip("inspection")}
                    aria-label="Show information about inspection contingency"
                  >
                    <HelpCircle size={16} />
                  </button>
                  {tooltips.inspection && (
                    <Tooltip
                      content="Allows you to back out of the deal or renegotiate if inspections reveal issues with the property."
                      onClose={() => toggleTooltip("inspection")}
                    />
                  )}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <button
                    type="button"
                    className={`p-3 rounded-lg border text-center ${
                      inspectionContingency === "Waived"
                        ? "bg-primary-100 border-primary-500 text-primary-700"
                        : "border-neutral-200 hover:border-primary-300"
                    }`}
                    onClick={() => setInspectionContingency("Waived")}
                  >
                    Waived
                  </button>
                  <button
                    type="button"
                    className={`p-3 rounded-lg border text-center ${
                      inspectionContingency === "Structural and Environmental"
                        ? "bg-primary-100 border-primary-500 text-primary-700"
                        : "border-neutral-200 hover:border-primary-300"
                    }`}
                    onClick={() => setInspectionContingency("Structural and Environmental")}
                  >
                    Structural & Environmental Only
                  </button>
                  <button
                    type="button"
                    className={`p-3 rounded-lg border text-center ${
                      inspectionContingency === "Complete"
                        ? "bg-primary-100 border-primary-500 text-primary-700"
                        : "border-neutral-200 hover:border-primary-300"
                    }`}
                    onClick={() => setInspectionContingency("Complete")}
                  >
                    Complete
                  </button>
                </div>
              </div>

              <div className="mb-6">
                <div className="flex items-center mb-2">
                  <label className="block text-neutral-700 font-medium">Financing Contingency</label>
                  <button
                    type="button"
                    className="ml-2 text-neutral-500"
                    onClick={() => toggleTooltip("financing")}
                    aria-label="Show information about financing contingency"
                  >
                    <HelpCircle size={16} />
                  </button>
                  {tooltips.financing && (
                    <Tooltip
                      content="Protects you if you're unable to secure financing. Only relevant if you're using a mortgage."
                      onClose={() => toggleTooltip("financing")}
                    />
                  )}
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    className={`p-3 rounded-lg border text-center ${
                      financingContingency === "Waived"
                        ? "bg-primary-100 border-primary-500 text-primary-700"
                        : "border-neutral-200 hover:border-primary-300"
                    }`}
                    onClick={() => setFinancingContingency("Waived")}
                    disabled={paymentMethod === "Cash"}
                  >
                    Waived
                  </button>
                  <button
                    type="button"
                    className={`p-3 rounded-lg border text-center ${
                      financingContingency === "Not Waived"
                        ? "bg-primary-100 border-primary-500 text-primary-700"
                        : "border-neutral-200 hover:border-primary-300"
                    }`}
                    onClick={() => setFinancingContingency("Not Waived")}
                    disabled={paymentMethod === "Cash"}
                  >
                    Not Waived
                  </button>
                </div>
              </div>

              <div className="mb-6">
                <div className="flex items-center mb-2">
                  <label className="block text-neutral-700 font-medium">Appraisal Contingency</label>
                  <button
                    type="button"
                    className="ml-2 text-neutral-500"
                    onClick={() => toggleTooltip("appraisal")}
                    aria-label="Show information about appraisal contingency"
                  >
                    <HelpCircle size={16} />
                  </button>
                  {tooltips.appraisal && (
                    <Tooltip
                      content="Protects you if the property appraises for less than your offer price. You can set a limit on how much you're willing to cover."
                      onClose={() => toggleTooltip("appraisal")}
                    />
                  )}
                </div>
                <div className="grid grid-cols-2 gap-3 mb-3">
                  <button
                    type="button"
                    className={`p-3 rounded-lg border text-center ${
                      appraisalContingency === "Waived"
                        ? "bg-primary-100 border-primary-500 text-primary-700"
                        : "border-neutral-200 hover:border-primary-300"
                    }`}
                    onClick={() => setAppraisalContingency("Waived")}
                  >
                    Waived
                  </button>
                  <button
                    type="button"
                    className={`p-3 rounded-lg border text-center ${
                      appraisalContingency === "Not Waived"
                        ? "bg-primary-100 border-primary-500 text-primary-700"
                        : "border-neutral-200 hover:border-primary-300"
                    }`}
                    onClick={() => setAppraisalContingency("Not Waived")}
                  >
                    Not Waived
                  </button>
                </div>

                {appraisalContingency === "Not Waived" && (
                  <div>
                    <label className="block text-neutral-700 text-sm mb-2">
                      Appraisal Gap Coverage (how much you're willing to pay above appraised value)
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-500">$</span>
                      <input
                        type="number"
                        value={appraisalGap}
                        onChange={(e) => setAppraisalGap(Number.parseInt(e.target.value))}
                        className="w-full pl-8 pr-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500"
                      />
                    </div>
                  </div>
                )}
              </div>

              <div className="mb-6">
                <label className="block text-neutral-700 font-medium mb-2">Additional Information</label>
                <textarea
                  value={additionalInfo}
                  onChange={(e) => setAdditionalInfo(e.target.value)}
                  className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500"
                  rows={4}
                  placeholder="Add any additional terms or information you'd like to include with your offer..."
                ></textarea>
              </div>

              <button
                type="submit"
                disabled={!closingDate || isSubmitting}
                className="w-full bg-primary-600 text-white py-3 px-4 rounded-lg font-medium flex items-center justify-center hover:bg-primary-700 transition-colors disabled:bg-neutral-300 disabled:cursor-not-allowed"
              >
                {isSubmitting ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-white mr-3"></div>
                    Submitting Offer...
                  </>
                ) : (
                  "Submit Offer"
                )}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  )
}


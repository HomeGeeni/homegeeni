"use client"

import { Home, Heart, Clipboard, User, MessageCircle } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { useState } from "react"
import ChatInterface from './ChatInterface'

export default function BottomNavigation() {
  const pathname = usePathname()
  const [isChatOpen, setIsChatOpen] = useState(false)

  const isActive = (path: string) => {
    return pathname.startsWith(path)
  }

  return (
    <>
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-neutral-200 py-2 px-4 flex justify-around items-center z-50 md:hidden">
        <Link
          href="/buyer"
          className={`flex flex-col items-center ${isActive("/buyer") ? "text-primary-600" : "text-neutral-500"}`}
        >
          <Home size={24} />
          <span className="text-xs mt-1">Home</span>
        </Link>
        <Link
          href="/preferences"
          className={`flex flex-col items-center ${isActive("/preferences") ? "text-primary-600" : "text-neutral-500"}`}
        >
          <Heart size={24} />
          <span className="text-xs mt-1">Preferences</span>
        </Link>

        {/* Chat Button */}
        <button
          onClick={() => setIsChatOpen(!isChatOpen)}
          className="flex flex-col items-center -mt-8 relative"
        >
          <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center shadow-lg">
            <MessageCircle size={28} className="text-white" />
          </div>
          <span className="text-xs mt-1 text-primary-600">Chat</span>
        </button>

        <Link
          href="/actions"
          className={`flex flex-col items-center ${isActive("/actions") ? "text-primary-600" : "text-neutral-500"}`}
        >
          <Clipboard size={24} />
          <span className="text-xs mt-1">Actions</span>
        </Link>
        <Link
          href="/profile"
          className={`flex flex-col items-center ${isActive("/profile") ? "text-primary-600" : "text-neutral-500"}`}
        >
          <User size={24} />
          <span className="text-xs mt-1">Profile</span>
        </Link>
      </div>

      {/* Chat Modal for Mobile */}
      {isChatOpen && (
        <div className="fixed inset-0 bg-white z-50 md:hidden">
          <div className="flex items-center justify-between p-4 border-b border-neutral-200">
            <h3 className="font-semibold">Chat with us</h3>
            <button 
              onClick={() => setIsChatOpen(false)}
              className="text-neutral-500 hover:text-neutral-700"
            >
              Close
            </button>
          </div>
          <div className="h-[calc(100%-65px)]">
            <ChatInterface />
          </div>
        </div>
      )}
    </>
  )
}


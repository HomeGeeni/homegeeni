'use client'

import { MessageCircle } from 'lucide-react'
import { useState } from 'react'
import ChatInterface from './ChatInterface'

export default function FloatingChat({ className = "" }: { className?: string }) {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <div className={`hidden md:block fixed bottom-8 right-8 z-50 ${className}`}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-14 h-14 bg-primary rounded-full flex items-center justify-center shadow-lg hover:bg-primary/90 transition-colors"
        aria-label="Open chat"
      >
        <MessageCircle className="w-6 h-6 text-white" />
      </button>

      {isOpen && (
        <div className="absolute bottom-16 right-0 w-[400px] h-[600px] bg-white rounded-lg shadow-xl border border-neutral-200">
          <div className="flex items-center justify-between p-4 border-b border-neutral-200">
            <h3 className="font-semibold">Chat with us</h3>
            <button 
              onClick={() => setIsOpen(false)}
              className="text-neutral-500 hover:text-neutral-700"
            >
              Close
            </button>
          </div>
          <div className="h-[calc(100%-65px)]">
            <ChatInterface />
          </div>
        </div>
      )}
    </div>
  )
} 
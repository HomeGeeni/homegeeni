"use client"

import { useState, useEffect } from "react"
import { Menu, X } from "lucide-react"
import Link from "next/link"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [displayText, setDisplayText] = useState("HomeGeeni.ai")
  const baseText = "HomeGeeni."
  const extensions = ["ai", "com"]
  const [currentExtIndex, setCurrentExtIndex] = useState(0)

  useEffect(() => {
    const animateText = async () => {
      // Backspace the current extension
      for (let i = extensions[currentExtIndex].length; i > 0; i--) {
        setDisplayText(baseText + extensions[currentExtIndex].slice(0, i))
        await new Promise(resolve => setTimeout(resolve, 150))
      }

      // Switch to next extension
      const nextIndex = (currentExtIndex + 1) % extensions.length
      setCurrentExtIndex(nextIndex)

      // Type the new extension
      for (let i = 1; i <= extensions[nextIndex].length; i++) {
        setDisplayText(baseText + extensions[nextIndex].slice(0, i))
        await new Promise(resolve => setTimeout(resolve, 150))
      }
    }

    const interval = setInterval(animateText, 5000)
    return () => clearInterval(interval)
  }, [currentExtIndex])

  return (
    <header className="bg-white border-b border-neutral-200 py-4 px-4 md:px-6 flex justify-between items-center sticky top-0 z-40">
      <div className="flex items-center">
        <Link href="/buyer" className="flex items-center">
          <span className="text-xl font-bold text-primary-600">
            {displayText}
          </span>
        </Link>
      </div>

      {/* Desktop Navigation */}
      <nav className="hidden md:flex items-center space-x-6">
        <Link href="/buyer" className="text-neutral-700 hover:text-primary-600">
          Home
        </Link>
        <Link href="/preferences" className="text-neutral-700 hover:text-primary-600">
          Preferences
        </Link>
        <Link href="/actions" className="text-neutral-700 hover:text-primary-600">
          Actions
        </Link>
        <Link href="/profile" className="text-neutral-700 hover:text-primary-600">
          Profile
        </Link>
      </nav>

      {/* Mobile Menu Button */}
      <div className="flex items-center md:hidden">
        <button className="p-2 text-neutral-700" onClick={() => setIsMenuOpen(!isMenuOpen)} aria-label="Toggle menu">
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="absolute top-full left-0 right-0 bg-white border-b border-neutral-200 shadow-lg md:hidden z-50">
          <nav className="flex flex-col py-4">
            <Link
              href="/buyer"
              className="px-6 py-3 text-neutral-700 hover:bg-neutral-100"
              onClick={() => setIsMenuOpen(false)}
            >
              Home
            </Link>
            <Link
              href="/preferences"
              className="px-6 py-3 text-neutral-700 hover:bg-neutral-100"
              onClick={() => setIsMenuOpen(false)}
            >
              Preferences
            </Link>
            <Link
              href="/actions"
              className="px-6 py-3 text-neutral-700 hover:bg-neutral-100"
              onClick={() => setIsMenuOpen(false)}
            >
              Actions
            </Link>
            <Link
              href="/profile"
              className="px-6 py-3 text-neutral-700 hover:bg-neutral-100"
              onClick={() => setIsMenuOpen(false)}
            >
              Profile
            </Link>
          </nav>
        </div>
      )}
    </header>
  )
}

